DISPLAY_NAME=svg-electrical-downloader
MEMORY=256
VERSION=recommended
AUTORESTART=true
MAIN=index.js