# SVG Electrical Downloader (Squarecloud)

Bot que baixa **todos** os SVGs listados em:
https://commons.wikimedia.org/wiki/Category:SVG_electrical_symbols

Usa a API oficial do MediaWiki (`action=query`, `list=categorymembers` +
`prop=imageinfo`), então não faz scraping de HTML — é o jeito correto e
estável de fazer isso, e a Wikimedia não bloqueia.

## Antes de rodar

1. Abra `index.js` e troque a constante `USER_AGENT` pelo seu contato real
   (a Wikimedia exige isso — é só uma linha de identificação, não precisa
   de e-mail funcional, mas deve ser algo identificável).
2. (Opcional) Se quiser baixar só uma subcategoria diferente, troque o
   valor de `CATEGORY`.

## Deploy na Squarecloud

1. Zipe a pasta `svg-bot` (ou os 3 arquivos: `index.js`, `package.json`,
   `squarecloud.app`).
2. No painel da Squarecloud, crie uma aplicação **Node.js** e faça upload
   do zip.
3. A aplicação vai rodar `node index.js` automaticamente (definido em
   `squarecloud.app`), baixar tudo e salvar na pasta `svgs/` dentro do
   próprio storage da aplicação.
4. Quando o log mostrar "Concluído", acesse o **File Manager** da
   Squarecloud (ou FTP/SFTP da aplicação) e baixe a pasta `svgs/` para o
   seu computador.

## Importante sobre licenciamento

Os arquivos do Commons são de uso livre, mas cada um pode ter uma licença
diferente (CC0, CC-BY, CC-BY-SA, domínio público etc.). Antes de
redistribuir esses SVGs dentro do seu portal/APK, vale conferir se algum
exige atribuição — isso normalmente está na página do próprio arquivo no
Commons. Se quiser, posso gerar também um `creditos.json` com a página de
origem de cada arquivo para facilitar isso.

## Rodando localmente (teste rápido, sem Squarecloud)

```bash
node index.js
```

Requer Node 18+ (usa `fetch` nativo).
