// Bot para baixar todos os SVGs da categoria "SVG_electrical_symbols"
// do Wikimedia Commons, usando a API oficial do MediaWiki.
// Feito para rodar na Squarecloud (Node.js >= 18, fetch nativo).

import fs from 'fs';
import path from 'path';

const CATEGORY = 'Category:SVG_electrical_symbols';
const API_URL = 'https://commons.wikimedia.org/w/api.php';

// A política da Wikimedia exige um User-Agent identificável.
// Troque o e-mail/URL abaixo pelo seu contato real antes de rodar.
const USER_AGENT = 'SVGElectricalDownloader/1.0 (https://assistente-diagnostico.squareweb.app; svgbot@squarecloud.app)';

const OUTPUT_DIR = path.join(process.cwd(), 'svgs');

async function apiRequest(params) {
  const url = new URL(API_URL);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const res = await fetch(url, { headers: { 'User-Agent': USER_AGENT } });
  if (!res.ok) throw new Error(`Erro na API (${res.status}) para ${url}`);
  return res.json();
}

// Lista todos os arquivos da categoria, paginando com cmcontinue
async function getCategoryFiles(cmtitle) {
  const files = [];
  let cmcontinue;
  do {
    const params = {
      action: 'query',
      list: 'categorymembers',
      cmtitle,
      cmtype: 'file',
      cmlimit: '500',
      format: 'json',
    };
    if (cmcontinue) params.cmcontinue = cmcontinue;

    const data = await apiRequest(params);
    const members = data.query?.categorymembers || [];
    files.push(...members.map((m) => m.title));
    cmcontinue = data.continue?.cmcontinue;
  } while (cmcontinue);
  return files;
}

// Resolve a URL real do arquivo (CDN do Commons) em lotes de 50 títulos
async function getFileUrls(titles) {
  const urlMap = {};
  for (let i = 0; i < titles.length; i += 50) {
    const batch = titles.slice(i, i + 50);
    const data = await apiRequest({
      action: 'query',
      titles: batch.join('|'),
      prop: 'imageinfo',
      iiprop: 'url',
      format: 'json',
    });
    const pages = data.query?.pages || {};
    Object.values(pages).forEach((page) => {
      const info = page.imageinfo?.[0];
      if (info?.url) urlMap[page.title] = info.url;
    });
  }
  return urlMap;
}

function sanitizeFilename(title) {
  return title.replace(/^File:/, '').replace(/[/\\?%*:|"<>]/g, '_');
}

async function downloadFile(url, destPath, retries = 3) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    const res = await fetch(url, {
      headers: {
        'User-Agent': USER_AGENT,
        'Referer': 'https://commons.wikimedia.org/',
        'Accept': 'image/svg+xml,image/*,*/*',
      },
    });

    if (res.ok) {
      const buffer = await res.arrayBuffer();
      fs.writeFileSync(destPath, Buffer.from(buffer));
      return;
    }

    if (res.status === 429 && attempt < retries) {
      const waitSec = attempt * 5; // 5s, 10s, 15s
      console.log(`  429 detectado, aguardando ${waitSec}s e tentando novamente (${attempt}/${retries})...`);
      await new Promise((r) => setTimeout(r, waitSec * 1000));
      continue;
    }

    // Se nao for 429 ou acabaram as tentativas, lanca erro
    throw new Error(`Falha ao baixar ${url}: ${res.status}`);
  }
}

async function main() {
  console.log('Buscando lista de arquivos na categoria do Commons...');
  const titles = await getCategoryFiles(CATEGORY);
  console.log(`Encontrados ${titles.length} arquivos na categoria.`);

  if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR, { recursive: true });

  console.log('Resolvendo URLs reais de download...');
  const urlMap = await getFileUrls(titles);
  const entries = Object.entries(urlMap);

  let ok = 0;
  let skipped = 0;
  let failed = 0;

  for (let i = 0; i < entries.length; i++) {
    const [title, url] = entries[i];
    const filename = sanitizeFilename(title);
    const destPath = path.join(OUTPUT_DIR, filename);

    if (fs.existsSync(destPath)) {
      skipped++;
      continue;
    }

    try {
      await downloadFile(url, destPath);
      ok++;
      console.log(`[${i + 1}/${entries.length}] OK: ${filename}`);
    } catch (err) {
      failed++;
      console.error(`[${i + 1}/${entries.length}] ERRO: ${filename} -> ${err.message}`);
    }

    // Pausa respeitosa para nao sobrecarregar a API/CDN da Wikimedia
    await new Promise((r) => setTimeout(r, 1500));
  }

  console.log('--------------------------------------------------');
  console.log(`Concluído. Baixados: ${ok} | Já existiam: ${skipped} | Falharam: ${failed}`);
  console.log(`Arquivos salvos em: ${OUTPUT_DIR}`);
}

main().catch((err) => {
  console.error('Erro fatal:', err);
  process.exit(1);
});
